create database cafebistro_phpoo_turmaab;
use cafebistro_phpoo_turmab;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;

